# SPDX-License-Identifier: MIT

from attr.exceptions import *  # noqa
